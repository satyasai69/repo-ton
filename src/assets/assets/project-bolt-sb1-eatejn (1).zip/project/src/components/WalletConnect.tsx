import React from 'react';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { TonConnectButton } from '@tonconnect/ui-react';
import { Wallet, Coins } from 'lucide-react';

const WalletConnect = () => {
  return (
    <div className="flex flex-col gap-4 w-full max-w-md">
      <div className="relative group">
        <ConnectButton.Custom>
          {({ account, chain, openConnectModal, mounted }) => {
            return (
              <button
                onClick={openConnectModal}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-4 px-6 rounded-xl shadow-lg transform transition-all duration-300 ease-in-out hover:scale-[1.02] flex items-center justify-center gap-3"
                disabled={!mounted}
              >
                <Wallet className="w-6 h-6" />
                {account ? account.displayName : 'Connect Ethereum Wallet'}
              </button>
            );
          }}
        </ConnectButton.Custom>
      </div>

      <div className="relative group">
        <TonConnectButton className="!w-full !bg-gradient-to-r !from-blue-500 !to-cyan-500 hover:!from-blue-600 hover:!to-cyan-600 !text-white !font-bold !py-4 !px-6 !rounded-xl !shadow-lg transform !transition-all !duration-300 !ease-in-out hover:!scale-[1.02] !flex !items-center !justify-center !gap-3" />
      </div>
    </div>
  );
};

export default WalletConnect;