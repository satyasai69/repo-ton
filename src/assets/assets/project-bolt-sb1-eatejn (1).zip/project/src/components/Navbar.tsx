import React from 'react';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { TonConnectButton } from '@tonconnect/ui-react';
import { Wallet, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const CustomTonButton = () => {
  return (
    <TonConnectButton className="flex w-full items-center px-2 py-1.5 text-sm !bg-transparent hover:!bg-accent !border-0" style={{
      width: '100%',
      justifyContent: 'flex-start',
      borderRadius: '0',
      backgroundColor: 'transparent',
    }}>
      <div className="flex items-center gap-2">
        <Wallet className="h-4 w-4" />
        Connect TON Wallet
      </div>
    </TonConnectButton>
  );
};

const Navbar = () => {
  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex">
          <a href="/" className="mr-6 flex items-center space-x-2">
            <Wallet className="h-6 w-6" />
            <span className="hidden font-bold sm:inline-block">
              Multi-Chain Wallet
            </span>
          </a>
        </div>

        <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
          <div className="w-full flex-1 md:w-auto md:flex-none">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center justify-between rounded-lg border px-3 py-2 w-full md:w-[200px] text-sm font-medium hover:bg-accent hover:text-accent-foreground">
                  Connect Wallet
                  <ChevronDown className="ml-2 h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                <DropdownMenuItem className="p-0">
                  <ConnectButton.Custom>
                    {({ account, chain, openConnectModal }) => (
                      <button
                        onClick={openConnectModal}
                        className="flex w-full items-center px-2 py-1.5 text-sm gap-2"
                      >
                        <Wallet className="h-4 w-4" />
                        {account ? account.displayName : 'Connect Ethereum Wallet'}
                      </button>
                    )}
                  </ConnectButton.Custom>
                </DropdownMenuItem>
                <DropdownMenuItem className="p-0">
                  <CustomTonButton />
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;