import React from 'react';
import { getDefaultConfig, RainbowKitProvider } from '@rainbow-me/rainbowkit';
import { WagmiProvider } from 'wagmi';
import { mainnet } from 'wagmi/chains';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TonConnectUIProvider } from '@tonconnect/ui-react';

const config = getDefaultConfig({
  appName: 'Multi-Chain Wallet Connect',
  projectId: 'YOUR_PROJECT_ID',
  chains: [mainnet],
});

const queryClient = new QueryClient();

export const WalletProviders = ({ children }: { children: React.ReactNode }) => {
  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider>
          <TonConnectUIProvider manifestUrl="https://your-app-url.com/tonconnect-manifest.json">
            {children}
          </TonConnectUIProvider>
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
};