import React from 'react';
import { WalletProviders } from './providers/WalletProviders';
import WalletConnect from './components/WalletConnect';
import { Coins } from 'lucide-react';

function App() {
  return (
    <WalletProviders>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-white/10 rounded-full">
                  <Coins className="w-12 h-12 text-purple-400" />
                </div>
              </div>
              <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">
                Connect Your Wallet
              </h1>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Seamlessly connect your Ethereum or TON wallet to access the next generation of decentralized applications.
              </p>
            </div>

            <div className="flex justify-center">
              <WalletConnect />
            </div>

            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="p-6 bg-white/5 rounded-xl backdrop-blur-sm">
                <h3 className="text-xl font-semibold mb-3">Secure Connection</h3>
                <p className="text-gray-400">Your assets remain secure with industry-standard encryption protocols</p>
              </div>
              <div className="p-6 bg-white/5 rounded-xl backdrop-blur-sm">
                <h3 className="text-xl font-semibold mb-3">Multi-Chain Support</h3>
                <p className="text-gray-400">Connect to multiple blockchains seamlessly through a single interface</p>
              </div>
              <div className="p-6 bg-white/5 rounded-xl backdrop-blur-sm">
                <h3 className="text-xl font-semibold mb-3">Easy Integration</h3>
                <p className="text-gray-400">Simple and intuitive connection process for the best user experience</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </WalletProviders>
  );
}

export default App;